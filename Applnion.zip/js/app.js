import * as flsFunction from './modules/testweb.js';

import { isMenu } from './modules/menu.js';

import { isMobile } from './modules/mobile.js';

import { isLanguage } from './modules/language.js';

import { isSwaper } from './modules/swiper.js';

import { isEmail } from './modules/email.js';

flsFunction.isWeb();
isMenu();
isMobile();
isLanguage();
isSwaper();
isEmail();
