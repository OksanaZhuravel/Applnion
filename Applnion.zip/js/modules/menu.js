// Открытие, закрытие мобильного меню
export function isMenu() {
  let navMain = document.querySelector('.nav'),
    navToggle = document.querySelector('.nav__toggle');

  navMain.classList.remove('nav--nojs');

  navToggle.addEventListener('click', function () {
    if (navMain.classList.contains('nav--closed')) {
      navMain.classList.remove('nav--closed');
      navMain.classList.add('nav--opened');
    } else {
      navMain.classList.add('nav--closed');
      navMain.classList.remove('nav--opened');
    }
  });
}
